// Este arquivo não é mais necessário e pode ser removido.
// A aplicação agora usa OpenStreetMap com Leaflet.js e não requer uma chave de API.
