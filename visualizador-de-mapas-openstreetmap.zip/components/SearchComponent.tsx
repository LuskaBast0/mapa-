import React, { useState } from 'react';
import type { Coordinates } from '../types';

interface SearchComponentProps {
  onPlaceSelected: (coordinates: Coordinates) => void;
}

const SearchComponent: React.FC<SearchComponentProps> = ({ onPlaceSelected }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;

    setLoading(true);
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=1`;

    try {
      const response = await fetch(url);
      const data = await response.json();
      if (data && data.length > 0) {
        const { lat, lon } = data[0];
        onPlaceSelected({
          lat: parseFloat(lat),
          lng: parseFloat(lon),
        });
      } else {
        alert('Local não encontrado. Tente novamente.');
      }
    } catch (error) {
      console.error("Erro ao buscar local:", error);
      alert('Ocorreu um erro ao buscar o local.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSearch} className="relative flex items-center">
      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
         <svg className="h-5 w-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
         </svg>
      </div>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Procurar um lugar..."
        className="w-full pl-12 pr-4 py-3 bg-gray-800 text-white border border-gray-600 rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
      />
      <button 
        type="submit" 
        disabled={loading}
        className="absolute inset-y-0 right-0 mr-2 flex items-center justify-center px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-full disabled:bg-gray-500"
      >
        {loading ? (
          <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        ) : 'Buscar'}
      </button>
    </form>
  );
};

export default SearchComponent;