import React, { useRef, useEffect, useState } from 'react';
import type { Coordinates } from '../types';

interface MapComponentProps {
  center: Coordinates;
  zoom: number;
}

const MapComponent: React.FC<MapComponentProps> = ({ center, zoom }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<any | null>(null);
  const [marker, setMarker] = useState<any | null>(null);

  // Efeito de inicialização do mapa
  useEffect(() => {
    if (mapRef.current && !map) {
      const newMap = window.L.map(mapRef.current).setView([center.lat, center.lng], zoom);
      
      window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(newMap);

      const newMarker = window.L.marker([center.lat, center.lng]).addTo(newMap);

      setMap(newMap);
      setMarker(newMarker);

      // Limpeza ao desmontar
      return () => {
        newMap.remove();
      };
    }
  }, []); // Executa apenas uma vez

  // Efeito para atualizar centro e marcador
  useEffect(() => {
    if (map) {
      map.setView([center.lat, center.lng], zoom);
      if (marker) {
        marker.setLatLng([center.lat, center.lng]);
      } else {
        const newMarker = window.L.marker([center.lat, center.lng]).addTo(map);
        setMarker(newMarker);
      }
    }
  }, [center, zoom, map, marker]);

  return <div ref={mapRef} className="w-full h-full" />;
};

export default MapComponent;