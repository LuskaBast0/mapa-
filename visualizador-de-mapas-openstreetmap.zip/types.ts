export interface Coordinates {
  lat: number;
  lng: number;
}

// Declara o objeto global L do Leaflet para o TypeScript
declare global {
  interface Window {
    L: any;
  }
}
