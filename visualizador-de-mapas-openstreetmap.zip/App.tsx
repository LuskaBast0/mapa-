import React, { useState, useCallback } from 'react';
import type { Coordinates } from './types';
import MapComponent from './components/MapComponent';
import SearchComponent from './components/SearchComponent';

const App: React.FC = () => {
  const [center, setCenter] = useState<Coordinates>({ lat: -14.2350, lng: -51.9253 }); // Default to Brazil
  const [zoom, setZoom] = useState<number>(4);

  const handlePlaceSelected = useCallback((coords: Coordinates) => {
    setCenter(coords);
    setZoom(15);
  }, []);

  return (
    <div className="relative w-screen h-screen">
      <MapComponent center={center} zoom={zoom} />
      <div className="absolute top-4 left-1/2 -translate-x-1/2 w-full max-w-md px-4 z-[1000]">
        <SearchComponent onPlaceSelected={handlePlaceSelected} />
      </div>
    </div>
  );
};

export default App;